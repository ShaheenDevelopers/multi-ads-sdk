package com.shaheendevelopers.ads.sdk.util;

public interface OnRewardedAdLoadedListener {
    void onRewardedAdLoaded();
}