package com.shaheendevelopers.ads.sdk.util;

public interface OnInterstitialAdShowedListener {
    void onInterstitialAdShowed();
}