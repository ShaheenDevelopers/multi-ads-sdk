package com.shaheendevelopers.ads.sdk.util;

public interface OnRewardedAdCompleteListener {
    void onRewardedAdComplete();
}