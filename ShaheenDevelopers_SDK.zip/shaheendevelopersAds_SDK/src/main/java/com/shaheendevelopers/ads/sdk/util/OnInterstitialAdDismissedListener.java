package com.shaheendevelopers.ads.sdk.util;

public interface OnInterstitialAdDismissedListener {
    void onInterstitialAdDismissed();
}