package com.shaheendevelopers.ads.sdk.util;

public interface OnRewardedAdErrorListener {
    void onRewardedAdError();
}