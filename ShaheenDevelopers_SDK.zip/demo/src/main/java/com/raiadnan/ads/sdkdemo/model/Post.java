package com.raiadnan.ads.sdkdemo.model;

import java.io.Serializable;

public class Post implements Serializable {

    public String name;
    public String image;

}
