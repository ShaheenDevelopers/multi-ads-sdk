package com.raiadnan.ads.sdkdemo.callback;

import com.raiadnan.ads.sdkdemo.model.Post;

import java.util.ArrayList;
import java.util.List;

public class CallbackConfig {

    public List<Post> android = new ArrayList<>();

}